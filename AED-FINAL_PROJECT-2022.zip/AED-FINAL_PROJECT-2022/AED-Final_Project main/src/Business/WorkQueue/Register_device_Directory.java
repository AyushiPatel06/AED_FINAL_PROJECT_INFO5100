/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.WorkQueue;

import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author ayushi
 */
public class Register_device_Directory {
    ArrayList<Register_device> us = new ArrayList<Register_device>();

    public ArrayList<Register_device> getarray() {
        return us;
    }

    public void setarray(ArrayList<Register_device> user) {
        this.us = user;
    }
    
    public void addrequest(Register_device user){
        us.add(user);
    }
    
    public void removerequest(Register_device user){
        us.remove(user);
    }
    
    
    
}
