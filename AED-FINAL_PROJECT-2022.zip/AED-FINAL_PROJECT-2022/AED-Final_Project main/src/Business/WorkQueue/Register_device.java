/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.WorkQueue;

import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author Rucha Mangalekar
 */
public class Register_device {
    String first_name;
    String last_name;
    String user_id;
    String appoinment_date;
    String Time;
    String blood_group;
    int id;
    String blood_bank_name;
    String appoinment_time;
    String status;
    int RBC;
    int WBC;
    int cholesterol;
    int platelets;

    public int getRBC() {
        return RBC;
    }

    public void setRBC(int RBC) {
        this.RBC = RBC;
    }

    public int getWBC() {
        return WBC;
    }

    public void setWBC(int WBC) {
        this.WBC = WBC;
    }

    public int getCholesterol() {
        return cholesterol;
    }

    public void setCholesterol(int cholesterol) {
        this.cholesterol = cholesterol;
    }

    public int getPlatelets() {
        return platelets;
    }

    public void setPlatelets(int platelets) {
        this.platelets = platelets;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getAppoinment_time() {
        return appoinment_time;
    }

    public void setAppoinment_time(String appoinment_time) {
        this.appoinment_time = appoinment_time;
    }

    public String getBlood_bank_name() {
        return blood_bank_name;
    }

    public void setBlood_bank_name(String blood_bank_name) {
        this.blood_bank_name = blood_bank_name;
    }

    public String getFirst_name() {
        return first_name;
    }

    public void setFirst_name(String first_name) {
        this.first_name = first_name;
    }

    public String getLast_name() {
        return last_name;
    }

    public void setLast_name(String last_name) {
        this.last_name = last_name;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getAppoinment_date() {
        return appoinment_date;
    }

    public void setAppoinment_date(String appoinment_date) {
        this.appoinment_date = appoinment_date;
    }

    public String getTime() {
        return Time;
    }

    public void setTime(String Time) {
        this.Time = Time;
    }

    public String getBlood_group() {
        return blood_group;
    }

    public void setBlood_group(String blood_group) {
        this.blood_group = blood_group;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
    

